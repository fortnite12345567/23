﻿namespace GamblersMod.GrabbableObjectCustom
{
    internal class GrabbableObjectCustom
    {
    }
}
