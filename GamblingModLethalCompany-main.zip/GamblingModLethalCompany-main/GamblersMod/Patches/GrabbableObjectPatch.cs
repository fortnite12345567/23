﻿using HarmonyLib;

namespace GamblersMod.Patches
{
    [HarmonyPatch(typeof(GrabbableObject))]
    internal class GrabbableObjectPatch
    {

    }
}
